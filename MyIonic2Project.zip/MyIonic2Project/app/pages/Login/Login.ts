import {Page, NavController, NavParams} from 'ionic-angular';
import {SignUpPage} from '../SignUp/SignUp';

@Page({
  templateUrl: 'build/pages/Login/Login.html'
})
export class LoginPage {

  constructor(private nav: NavController, navParams: NavParams) {
    // If we navigated to this page, we will have an item available as a nav param
   
  }
  
  itemTapped(event, item) {
    this.nav.push(SignUpPage, {});

  } 

 
}

