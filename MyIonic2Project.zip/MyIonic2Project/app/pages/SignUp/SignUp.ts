import {Page, NavController, NavParams} from 'ionic-angular';
import {LoginPage} from '../Login/Login';

@Page({
  templateUrl: 'build/pages/SignUp/SignUp.html'
})
export class SignUpPage {

  constructor(private nav: NavController, navParams: NavParams) {
    // If we navigated to this page, we will have an item available as a nav param
   
  }

  itemTapped(event, item) {
    this.nav.push(LoginPage, {});

  } 
}

